const ParkingSlot = require("../models/ParkingSlot");

const cleanupExpiredReservations = async () => {
  const now = new Date();

  const slots = await ParkingSlot.find({
    currentReservationId: { $ne: null }
  }).populate('currentReservationId');

  let cleanedCount = 0;

  for (const slot of slots) {
    const reservation = slot.currentReservationId;
    if (
      reservation &&
      reservation.endTime < now &&
      reservation.payment &&
      reservation.payment.status === 'success'
    ) {
      await ParkingSlot.findByIdAndUpdate(slot._id, {
        isAvailable: true,
        currentReservationId: null
      });

      cleanedCount++;
    }
  }

  console.log(`[Passive Cleanup] Freed ${cleanedCount} expired parking slots.`);
};

module.exports = cleanupExpiredReservations;