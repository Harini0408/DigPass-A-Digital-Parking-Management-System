const express = require('express');
const router = express.Router();
const { loginInternalUser, logoutInternalUser, forgotPassword } = require('../controllers/internalUserController');

router.post('/login', loginInternalUser);
router.post('/logout', logoutInternalUser);
router.post('/forgot-password', forgotPassword);

module.exports = router;
