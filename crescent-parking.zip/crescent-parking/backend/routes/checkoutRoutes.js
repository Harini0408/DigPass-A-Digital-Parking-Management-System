const express = require('express');
const router = express.Router();
const { checkoutSlot } = require('../controllers//checkoutController');

router.get('/:slotId', checkoutSlot);

module.exports = router;
