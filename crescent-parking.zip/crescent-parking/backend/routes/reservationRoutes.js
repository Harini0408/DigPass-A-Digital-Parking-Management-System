const express = require('express');
const { verifyReservation, getAllReservations } = require('../controllers/reservationController');
const router = express.Router();

router.post('/verify', verifyReservation);
router.get('/all', getAllReservations);

module.exports = router;
