const express = require('express');
const router = express.Router();
const { getAvailableSlots } = require('../controllers/slotController');

router.get('/available/:vehicleType', getAvailableSlots);

module.exports = router;
