const ParkingSlot = require('../models/ParkingSlot');
const cleanupExpiredReservations = require('../utils/cleanup');


const getAvailableSlots = async (req, res) => {
  try {
    await cleanupExpiredReservations();

    const { vehicleType } = req.params;
    const availableSlots = await ParkingSlot.find({ type: vehicleType },{_id:0, currentReservationId:0, createdAt:0, updatedAt:0, __v:0});

    res.json(availableSlots);
  } catch (err) {
    console.error('Error getting available slots:', err.message);
    res.status(500).json({ error: 'Server error' });
  }
};

module.exports = { getAvailableSlots };
