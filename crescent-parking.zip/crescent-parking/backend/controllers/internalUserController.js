const InternalUser = require('../models/InternalUser');
const jwt = require('jsonwebtoken');
const nodemailer = require('nodemailer');

const loginInternalUser = async (req, res) => {
    const { registerNumber, password } = req.body;

    if (!registerNumber || !password) {
        return res.status(400).json({ message: 'Register number and password are required' });
    }

    try {
        const user = await InternalUser.findOne({ registerNumber });

        if (!user) {
            return res.status(404).json({ message: 'User not found' });
        }

        if (user.password !== password) {
            return res.status(401).json({ message: 'Invalid credentials' });
        }

        // Sign the token
        const token = jwt.sign(
            {
                id: user._id,
                registerNumber: user.registerNumber,
                role: user.role,
            },
            process.env.JWT_SECRET,
            { expiresIn: process.env.JWT_EXPIRY }
        );

        // Set cookie
        res.cookie('token', token, {
            httpOnly: true,
            secure: false,
            sameSite: 'Lax',
            maxAge: 1000 * 60 * 60, // 1 hour
        });

        res.cookie('userInfo', JSON.stringify({
            name: user.name,
            role: user.role
        }), {
            httpOnly: false,
            sameSite: 'Lax',
            maxAge: 60 * 60 * 1000, // 1 hour
            secure: false
        });

        res.status(200).json({ message: 'Login successful' });
    } catch (error) {
        console.error('Login error:', error);
        res.status(500).json({ message: 'Server error' });
    }
};

const logoutInternalUser = (req, res) => {
    res.clearCookie('token', {
      httpOnly: true,
      sameSite: 'Lax',
      secure: false,
    });
  
    res.clearCookie('userInfo', {
      sameSite: 'Lax',
      secure: false,
    });
  
    res.status(200).json({ message: 'Logged out successfully' });
};  

const forgotPassword = async (req, res) => {
    const { registerNumber, email } = req.body;
  
    try {
      const user = await InternalUser.findOne({ registerNumber, email });
  
      if (!user) {
        return res.status(404).json({ message: 'User not found with provided details' });
      }
  
      // Set up nodemailer transporter (using Gmail here)
      const transporter = nodemailer.createTransport({
        service: 'gmail',
        auth: {
          user: process.env.SENDER_MAIL,       // Your email
          pass: process.env.GMAIL_APP_PASSWORD,          // Gmail App Password (not your actual password!)
        },
      });
  
      const mailOptions = {
        from: process.env.SENDER_MAIL,
        to: user.email,
        subject: 'Cresent Parking App Password',
        html: `
          <p>Hello <strong>${user.name}</strong>,</p>
          <p>You requested your password. Here it is:</p>
          <h3>${user.password}</h3>
          <p>Please keep it safe.</p>
        `,
      };
  
      await transporter.sendMail(mailOptions);
  
      res.status(200).json({ message: 'Password sent to your email address' });
  
    } catch (error) {
      console.error('Forgot Password Error:', error);
      res.status(500).json({ message: 'Something went wrong' });
    }
  };

module.exports = { loginInternalUser, logoutInternalUser, forgotPassword };
