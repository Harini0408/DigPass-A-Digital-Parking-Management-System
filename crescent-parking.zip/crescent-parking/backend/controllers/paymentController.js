const Razorpay = require('razorpay');
const jwt = require('jsonwebtoken');
const crypto = require('crypto');
const Reservation = require('../models/Reservation');
const InternalUser = require('../models/InternalUser');
const ExternalUser = require('../models/ExternalUser');
const ParkingSlot = require('../models/ParkingSlot');
const nodemailer = require('nodemailer');
const QRCode = require('qrcode');

const razorpay = new Razorpay({
  key_id: process.env.RAZORPAY_KEY_ID,
  key_secret: process.env.RAZORPAY_KEY_SECRET
});

exports.createOrder = async (req, res) => {
  const {
    name,
    email,
    slotId,
    validity,
    amount,
    vehicleNumber
  } = req.body;

  try {
    const slot = await ParkingSlot.findOne({ slotId: slotId });
    if (!slot || slot.isAvailable==false) return res.status(404).json({ message: 'Slot is not available' });

    let userId, userTypeRef;

    // Try verifying JWT token from cookies
    const token = req.cookies?.token;
    if (token) {
      const decoded = jwt.verify(token, process.env.JWT_SECRET);
      const internalUser = await InternalUser.findById(decoded.id);
      if (!internalUser) throw new Error('Invalid internal user');
      userId = internalUser._id;
      userTypeRef = 'InternalUser';
    } else {
      // External user — create or find existing
      let externalUser = await ExternalUser.findOne({ email });
      if (!externalUser) {
        externalUser = await ExternalUser.create({ name, email });
      }
      userId = externalUser._id;
      userTypeRef = 'ExternalUser';
    }

    // Create Razorpay order
    const order = await razorpay.orders.create({
      amount: amount * 100,
      currency: 'INR',
      receipt: `receipt_${Date.now()}`
    });

    // Create reservation in DB
    const reservation = await Reservation.create({
      userId,
      userTypeRef,
      parkingSlotId: slot._id,
      vehicleNumber,
      startTime: new Date(),
      endTime: new Date(Date.now() + validity * 24 * 60 * 60 * 1000),
      payment: {
        razorpayOrderId: order.id,
        amount,
        currency: 'INR',
        status: 'created'
      }
    });

    res.json({
      success: true,
      razorpayOrderId: order.id,
      amount: order.amount,
      keyId: process.env.RAZORPAY_KEY_ID,
      reservationId: reservation._id
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};


exports.verifyPayment = async (req, res) => {
    const {
      reservationId,
      razorpay_order_id,
      razorpay_payment_id,
      razorpay_signature
    } = req.body;
  
    const body = `${razorpay_order_id}|${razorpay_payment_id}`;
    const expectedSignature = crypto
      .createHmac('sha256', process.env.RAZORPAY_KEY_SECRET)
      .update(body.toString())
      .digest('hex');
  
    const isValid = expectedSignature === razorpay_signature;
  
    try {
      const reservation = await Reservation.findById(reservationId).populate('userId').populate('parkingSlotId');
      if (!reservation) throw new Error('Reservation not found');
  
      // Update payment info
      reservation.payment.razorpayPaymentId = razorpay_payment_id;
      reservation.payment.razorpaySignature = razorpay_signature;
      reservation.payment.status = isValid ? 'success' : 'failed';
      reservation.updatedAt = new Date();
      await reservation.save();
  
      if (isValid) {
        // Update parking slot
        await ParkingSlot.findByIdAndUpdate(reservation.parkingSlotId._id, {
          isAvailable: false,
          currentReservationId: reservation._id
        });
  
        // Prepare mail content
        const recipient = reservation.userId.email;
        const transporter = nodemailer.createTransport({
          service: 'gmail',
          auth: {
            user: process.env.SENDER_MAIL,
            pass: process.env.GMAIL_APP_PASSWORD
          }
        });
  
        const mailOptions = {
          from: process.env.SENDER_MAIL,
          to: recipient,
          subject: 'Cresent Parking | Parking Reservation Confirmed',
          html: `
            <h2>Parking Reservation Confirmed</h2>
            <p><strong>Parking Slot:</strong> ${reservation.parkingSlotId.slotId}</p>
            <p><strong>Vehicle:</strong> ${reservation.vehicleNumber}</p>
            <p><strong>From:</strong> ${new Date(reservation.startTime).toLocaleString()}</p>
            <p><strong>To:</strong> ${new Date(reservation.endTime).toLocaleString()}</p>
            <p><strong>Amount:</strong> ₹${reservation.payment.amount}</p>
            <p><strong>Name:</strong> ${reservation.userId.name}</p>
            <p><strong>Email:</strong> ${reservation.userId.email}</p>
            ${reservation.userTypeRef=='InternalUser' ? `<p><strong>Register Number:</strong> ${reservation.userId.registerNumber}</p>` : ``}
            <br/>
            <p>Show this QR code at the gate:</p>
            <img src="https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=${reservation._id.toString()}" width="200"/>
          `
        };
  
        await transporter.sendMail(mailOptions);
      }
  
      res.json({
        success: isValid,
        message: isValid ? 'Payment verified, reservation confirmed & QR sent via email' : 'Payment verification failed'
      });
  
    } catch (err) {
      console.error(err);
      res.status(500).json({ success: false, message: err.message });
    }
  };