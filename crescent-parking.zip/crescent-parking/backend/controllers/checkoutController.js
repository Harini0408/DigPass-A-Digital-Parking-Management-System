const jwt = require('jsonwebtoken');
const InternalUser = require('../models/InternalUser');
const ParkingSlot = require('../models/ParkingSlot');

const checkoutSlot = async (req, res) => {
    const { slotId } = req.params;
    const token = req.cookies?.token;

    try {
        // Check slot availability
        const slot = await ParkingSlot.findOne({ slotId, isAvailable: true });
        if (!slot) {
            return res.status(404).json({ message: 'Slot not available' });
        }

        // If token exists, treat as internal/admin user
        if (token) {
            let decoded;
            try {
                decoded = jwt.verify(token, process.env.JWT_SECRET);
            } catch (err) {
                return res.status(401).json({ message: 'Invalid or expired token' });
            }

            const userId = decoded.id;
            const user = await InternalUser.findById(userId);
            if (!user) {
                return res.status(403).json({ message: 'User not found' });
            }

            return res.status(200).json({
                slotId,
                isAvailable: true,
                vehicleType:slot.type,
                userType:'internal',
                name: user.name,
                email: user.email,
                registerNumber: user.registerNumber,
                validity: 30,
                amount: 250
            });
        }

        // No token = external user
        return res.status(200).json({
            slotId,
            isAvailable: true,
            userType:'external',
            vehicleType:slot.type,
            validity: 1,
            amount: 10
        });

    } catch (error) {
        console.error('Checkout error:', error);
        return res.status(500).json({ message: 'Server error' });
    }
};

module.exports = {
    checkoutSlot
};
