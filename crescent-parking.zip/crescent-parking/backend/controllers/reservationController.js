const jwt = require('jsonwebtoken');
const Reservation = require('../models/Reservation');
const InternalUser = require('../models/InternalUser');
const ExternalUser = require('../models/ExternalUser');

const verifyReservation = async (req, res) => {
    try {
        const token = req.cookies.token;
        if (!token) return res.status(401).json({ error: 'Unauthorized' });

        const decoded = jwt.verify(token, process.env.JWT_SECRET);
        const adminUser = await InternalUser.findById(decoded.id);
        if (!adminUser || adminUser.role !== 'admin') {
            return res.status(403).json({ error: 'Forbidden: Not an admin' });
        }

        const { reservationId } = req.body;
        const reservation = await Reservation.findById(reservationId).populate('parkingSlotId');

        if (!reservation) {
            return res.status(404).json({ error: 'Reservation not found' });
        }

        const now = new Date();
        if (now < reservation.startTime || now > reservation.endTime) {
            return res.status(400).json({ error: 'Reservation not valid at this time' });
        }

        let user = null;
        if (reservation.userTypeRef === 'InternalUser') {
            user = await InternalUser.findById(reservation.userId);
        } else {
            user = await ExternalUser.findById(reservation.userId);
        }

        return res.json({
            message: 'Reservation is valid',
            reservationDetails: {
                slotId: reservation.parkingSlotId.slotId,
                slotType: reservation.parkingSlotId.type,
                userEmail: user.email,
                userName: user.name,
                vehicleNumber: reservation.vehicleNumber,
                startTime: reservation.startTime,
                endTime: reservation.endTime
            }
        });

    } catch (err) {
        console.error(err);
        return res.status(500).json({ error: 'Server error' });
    }
};

const getAllReservations = async (req, res) => {
    try {
        const token = req.cookies.token;
        if (!token) {
            return res.status(401).json({ error: 'Unauthorized access' });
        }

        const decoded = jwt.verify(token, process.env.JWT_SECRET);
        const admin = await InternalUser.findById(decoded.id);

        if (!admin || admin.role !== 'admin') {
            return res.status(403).json({ error: 'Unauthorized access' });
        }

        const reservations = await Reservation.find({ 'payment.status': 'success' })
            .sort({ endTime: -1 }) // ascending order
            .populate('parkingSlotId')
            .lean();

        const now = new Date();

        const populated = await Promise.all(reservations.map(async (resv) => {
            const userModel = resv.userTypeRef === 'InternalUser' ? InternalUser : ExternalUser;
            const user = await userModel.findById(resv.userId);

            return {
                _id: resv._id,
                userName: user?.name,
                userEmail: user?.email,
                userType: resv.userTypeRef,
                vehicleNumber: resv.vehicleNumber,
                slotId: resv.parkingSlotId?.slotId,
                slotType: resv.parkingSlotId?.type,
                startTime: resv.startTime,
                endTime: resv.endTime,
                paymentStatus: resv.payment.status,
                isExpired: new Date(resv.endTime) < now
            };
        }));

        res.json(populated);

    } catch (err) {
        console.error(err);
        res.status(500).json({ error: 'Server error' });
    }
};

module.exports = { verifyReservation, getAllReservations };
