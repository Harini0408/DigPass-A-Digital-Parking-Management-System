const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const cookieParser = require('cookie-parser');
require('dotenv').config();
const slotRoutes = require('./routes/slotRoutes');
const internalUserRoutes = require('./routes/internalUserRoutes');
const checkoutRoutes = require('./routes/checkoutRoutes')
const paymentRoutes = require('./routes/paymentRoutes')
const reservationRoutes = require('./routes/reservationRoutes');

const app = express();
app.use(cors({
    origin: 'http://localhost:5173', // frontend origin
    credentials: true
  }));
app.use(express.json());
app.use(cookieParser());

app.get('/', (req, res) => res.send('API is running'));

app.use('/api/slots', slotRoutes);
app.use('/api/internalUser', internalUserRoutes);
app.use('/api/checkout', checkoutRoutes);
app.use('/api/payment', paymentRoutes);
app.use('/api/reservation', reservationRoutes);

mongoose.connect(process.env.MONGO_URI).then(() => {
    console.log('MongoDB connected');
    app.listen(process.env.PORT || 5000, () => {
        console.log(`Server running on port ${process.env.PORT || 5000}`);
    });
}).catch(err => console.error(err));
