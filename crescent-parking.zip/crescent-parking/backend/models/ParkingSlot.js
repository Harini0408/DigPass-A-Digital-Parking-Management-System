const mongoose = require('mongoose');

const parkingSlotSchema = new mongoose.Schema({
  slotId: { type: String, required: true, unique: true }, // e.g., B1, C2
  type: { type: String, enum: ['bike', 'car'], required: true },
  isAvailable: { type: Boolean, default: true },
  currentReservationId: { type: mongoose.Schema.Types.ObjectId, ref: 'Reservation', default: null },
  createdAt: { type: Date, default: Date.now },
  updatedAt: { type: Date, default: Date.now }
});

module.exports = mongoose.model('ParkingSlot', parkingSlotSchema);
