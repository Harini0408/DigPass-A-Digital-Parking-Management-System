const mongoose = require('mongoose');
const ParkingSlot = require('../models/ParkingSlot');

mongoose.connect('mongodb+srv://jv8110909191:ASas12.,@cluster0.qsdf4.mongodb.net/cp?retryWrites=true&w=majority&appName=Cluster0')
  .then(() => {
    console.log('Connected to MongoDB');
    insertSlots();
  }).catch(err => {
    console.error('Connection error', err);
  });

async function insertSlots() {
  try {
    const slots = [];

    for (let i = 1; i <= 50; i++) {
      slots.push({
        slotId: `C${i}`,
        type: 'car'
      });
    }

    for (let i = 1; i <= 50; i++) {
      slots.push({
        slotId: `B${i}`,
        type: 'bike'
      });
    }

    await ParkingSlot.insertMany(slots);
    console.log('parking slots inserted successfully!');
  } catch (error) {
    console.error('Error inserting slots:', error);
  } finally {
    mongoose.disconnect();
  }
}
