const fs = require('fs');
const csv = require('csv-parser');
const mongoose = require('mongoose');
const InternalUsers = require('../models/InternalUser');

// Connect to MongoDB
mongoose.connect('mongodb+srv://jv8110909191:ASas12.,@cluster0.qsdf4.mongodb.net/cp?retryWrites=true&w=majority&appName=Cluster0')
    .then(() => {
        console.log('Connected to MongoDB');
    }).catch(err => {
        console.error('MongoDB connection error:', err);
    });

function generateRandomPassword(length = 8) {
    const chars = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789@#$';
    let password = '';
    for (let i = 0; i < length; i++) {
        password += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    return password;
}

const users = [];

fs.createReadStream('./InternalUsers.csv')
    .pipe(csv())
    .on('data', (row) => {
        const password = generateRandomPassword();
        users.push({
            name: row.name,
            email: row.email,
            registerNumber: row.registerNumber,
            role: row.role,
            password,
        });
    })
    .on('end', async () => {
        try {
            await InternalUsers.insertMany(users);
            console.log('Users inserted successfully!');
        } catch (error) {
            console.error('Error inserting users:', error);
        } finally {
            mongoose.disconnect();
        }
    });
