const mongoose = require('mongoose');
const ParkingSlot = require('../models/ParkingSlot');
const ExternalUser = require('../models/ExternalUser');
const InternalUser = require('../models/InternalUser');
const Reservation = require('../models/Reservation');

mongoose.connect('mongodb+srv://jv8110909191:ASas12.,@cluster0.qsdf4.mongodb.net/cp?retryWrites=true&w=majority&appName=Cluster0')
  .then(() => {
    console.log('Connected to MongoDB');
    ClearDb();
  }).catch(err => {
    console.error('Connection error', err);
  });

async function ClearDb() {
  try {
    await ParkingSlot.deleteMany({})
    await ExternalUser.deleteMany({})
    // await InternalUser.deleteMany({})
    await Reservation.deleteMany({})
    console.log('db deleted successfully!');
  } catch (error) {
    console.error(error);
  } finally {
    mongoose.disconnect();
  }
}
