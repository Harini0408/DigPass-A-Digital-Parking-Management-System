// require('dotenv').config();
// const QRCode = require('qrcode');
// const nodemailer = require('nodemailer');

// async function sendQrEmail() {
//   const recipient = 'jv8110909191@gmail.com'; // Replace with actual recipient
//   const reservationId = 'ABC123456789'; // Simulate a reservation ID
  
//   try {
//     // Generate QR code with reservation ID
//     const qrCodeDataUrl = await QRCode.toDataURL(reservationId);

//     // Create transporter
//     const transporter = nodemailer.createTransport({
//       service: 'gmail',
//       auth: {
//         user: 'jv8110909191@gmail.com',
//         pass: 'tgsh vhvu fbmm yqrz'
//       }
//     });

//     // Email content
//     const mailOptions = {
//       from: 'jv8110909191@gmail.com',
//       to: recipient,
//       subject: 'Parking Reservation Confirmed',
//       html: `
//         <img src="https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=Example" width="200" />
//       `
//     };

//     // Send mail
//     await transporter.sendMail(mailOptions);
//     console.log('✅ Email sent successfully to', recipient);
//   } catch (err) {
//     console.error('❌ Error sending email:', err);
//   }
// }

// sendQrEmail();
