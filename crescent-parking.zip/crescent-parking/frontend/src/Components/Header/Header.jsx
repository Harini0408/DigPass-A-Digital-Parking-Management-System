import React, { useEffect, useState } from 'react'
import './Header.css'
import { Link, useNavigate } from 'react-router-dom'

const Header = () => {
  const navigate = useNavigate();
  const [userInfo, setUserInfo] = useState(null);

  useEffect(() => {
    const cookie = document.cookie
      .split('; ')
      .find(row => row.startsWith('userInfo='));

    if (cookie) {
      try {
        const _userInfo = JSON.parse(decodeURIComponent(cookie.split('=')[1]));
        setUserInfo(_userInfo);
      } catch (err) {
        console.log(err)
      }
    }
  }, [])

  const handleLogout = () => {
    fetch(`${import.meta.env.VITE_BACKEND_URL}/api/internalUser/logout`, {
      method: 'POST',
      credentials: 'include',
    })
      .then(res => res.json())
      .then(data => {
        if (data.message == 'Logged out successfully') {
          window.location.href = '/';
        }
      })
      .catch(err => console.error(err));
  }

  return (
    <div className='header'>
      <img src="/assets/logo.png" alt="logo" className='header-logo' onClick={() => { navigate('/') }} />
      <div className='header-options'>
        {
          (userInfo == null &&
            <>
              <Link className='header-option' to='/login'>Student / Staff Login <svg xmlns="http://www.w3.org/2000/svg" width="40" height="40" viewBox="0 0 24 24"><path fill="currentColor" d="m11.71 15.29l2.59-2.59a.996.996 0 0 0 0-1.41L11.71 8.7c-.63-.62-1.71-.18-1.71.71v5.17c0 .9 1.08 1.34 1.71.71"/></svg></Link>
            </>
          )
        }
        {
          (userInfo?.role == 'admin' &&
            <>
              <div className='header-profile'>Hello {userInfo.name}</div>
              <Link className='header-option' to='/bookings'>Bookings</Link>
              <Link className='header-option' to='/scanner'>Pass Validation</Link>
              <button className='header-button' onClick={handleLogout}>Logout</button>
            </>
          )
        }
        {
          (userInfo?.role == 'internal' &&
            <>
              <div className='header-profile'>Hello {userInfo.name}</div>
              <button className='header-button' onClick={handleLogout}>Logout</button>
            </>
          )
        }
      </div>
    </div>
  )
}

export default Header