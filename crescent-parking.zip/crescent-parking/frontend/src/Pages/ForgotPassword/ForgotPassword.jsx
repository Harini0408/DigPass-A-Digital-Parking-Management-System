import React, { useEffect, useState } from 'react'
import './ForgotPassword.css'
import { Link, useNavigate } from 'react-router-dom';

const ForgotPassword = ({ setLoading }) => {
    const navigate = useNavigate();
    const [forgotPasswordData, setForgotPasswordData] = useState({
        registerNumber: "",
        email: ""
    });

    const handleTextInput = (event) => {
        setForgotPasswordData(prev => ({
            ...prev,
            [event.target.name]: event.target.value
        }));
    };

    const handleForgotPasswordSubmit = () => {
        setLoading(true)
        fetch(`${import.meta.env.VITE_BACKEND_URL}/api/internalUser/forgot-password`, {
            method: 'POST',
            credentials: 'include',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ ...forgotPasswordData })
        })
            .then(res => res.json())
            .then(data => {
                if (data.message == 'Password sent to your email address') {
                    navigate(`/status/success/${data.message}`)
                }
                else {
                    alert(data.message);
                }
            })
            .catch(err => console.log(err))
            .finally(() => { setLoading(false) })
    }

    useEffect(() => {
        const cookieString = document.cookie;
        const match = cookieString.match(/userInfo=([^;]+)/);
        if (match) {
            navigate('/')
        }
    }, [])

    return (
        <div className='login'>
            <img src="/assets/logo.png" alt="logo" className='login-logo' />
            <div className='login-heading'>Forgot Password</div>
            <input
                type="text"
                placeholder='Register Number'
                name='registerNumber'
                onChange={handleTextInput}
                value={forgotPasswordData.registerNumber}
            />
            <input
                type="text"
                placeholder='Email'
                name='email'
                onChange={handleTextInput}
                value={forgotPasswordData.email}
            />
            <button className='login-submit' onClick={() => handleForgotPasswordSubmit()}>Send password to mail</button>
            <div className='login-links'>
                <Link to='/'>Home</Link>
                <Link to='/login'>Login</Link>
            </div>
        </div>
    );
}

export default ForgotPassword