import React, { useEffect, useState } from 'react';
import './Checkout.css';
import { useParams, useNavigate } from 'react-router-dom';
import Header from '../../Components/Header/Header';

const Checkout = ({ setLoading }) => {
  const { selectedSlot } = useParams();
  const navigate = useNavigate();
  const [checkoutResponse, setCheckoutResponse] = useState(null);
  const [createOrderRequest, setCreateOrderRequest] = useState({
    slotId: '',
    amount: '',
    validity: '',
    name: '',
    email: '',
    vehicleNumber: '',
  });

  useEffect(() => {
    setLoading(true);
    fetch(`${import.meta.env.VITE_BACKEND_URL}/api/checkout/${selectedSlot}`, {
      method: 'GET',
      credentials: 'include',
    })
      .then(res => res.json())
      .then(data => {
        if (data.message) {
          alert(data.message);
          navigate('/');
        } else {
          setCheckoutResponse(data);
          setCreateOrderRequest(prev => ({
            ...prev,
            name: data.name || '',
            email: data.email || '',
            slotId: data.slotId,
            validity: data.validity,
            amount: data.amount
          }));
        }
      })
      .catch(err => console.log(err))
      .finally(() => setLoading(false));
  }, []);

  const handleTextInput = (e) => {
    setCreateOrderRequest(prev => ({
      ...prev,
      [e.target.name]: e.target.value
    }));
  };

  const validateFields = () => {
    const { name, email, vehicleNumber } = createOrderRequest;
    if (!name || !email || !vehicleNumber) {
      alert('Please fill all required fields');
      return false;
    }
    return true;
  };

  const handlePayment = async () => {
    if (!validateFields()) return;

    try {
      setLoading(true);
      const orderRes = await fetch(`${import.meta.env.VITE_BACKEND_URL}/api/payment/create-order`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify(createOrderRequest),
      });

      const orderData = await orderRes.json();
      console.log(orderData)
      const { razorpayOrderId, amount, keyId, reservationId } = orderData
      const options = {
        key: keyId,
        amount: amount.toString(),
        currency: 'INR',
        name: 'Campus Parking',
        description: 'Reservation Payment',
        order_id: razorpayOrderId,
        handler: async function (response) {
          setLoading(true)
          const verifyRes = await fetch(`${import.meta.env.VITE_BACKEND_URL}/api/payment/verify`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            credentials: 'include',
            body: JSON.stringify({
              reservationId,
              razorpay_order_id: response.razorpay_order_id,
              razorpay_payment_id: response.razorpay_payment_id,
              razorpay_signature: response.razorpay_signature,
            }),
          });

          const verifyResult = await verifyRes.json();
          if (verifyRes.ok) {
            setLoading(false)
            if(verifyResult.message == 'Payment verification failed')
              navigate(`/status/failed/${verifyResult.message}`);
            else
              navigate(`/status/success/${verifyResult.message}`);
          } else {
            setLoading(false)
            alert(verifyResult.message || 'Payment verification failed.');
          }
        },
        prefill: {
          name: createOrderRequest.name,
          email: createOrderRequest.email,
        },
        theme: {
          color: '#7D4FFF',
        },
      };

      const rzp = new window.Razorpay(options);
      rzp.open();
    } catch (err) {
      console.error(err);
      alert('Payment failed. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <>
      <Header />
      {
        checkoutResponse &&
        <div className='checkout'>
          <div className='checkout-form'>
            <input type="text" placeholder='Name' name='name' disabled={checkoutResponse.userType === 'internal'} value={createOrderRequest.name} onChange={handleTextInput} />
            {checkoutResponse.userType === 'internal' &&
              <input type="text" placeholder='Register Number' name='registerNumber' disabled value={checkoutResponse.registerNumber} />
            }
            <input type="text" placeholder='Email' name='email' disabled={checkoutResponse.userType === 'internal'} value={createOrderRequest.email} onChange={handleTextInput} />
            <input type="text" placeholder='Vehicle Number' name='vehicleNumber' value={createOrderRequest.vehicleNumber} onChange={handleTextInput} />
          </div>
          <div className='checkout-receipt'>
            <div className='checkout-receipt-data'>Selected slot <span>{createOrderRequest.slotId}</span></div>
            <div className='checkout-receipt-data'>Vehicle type  <span>{checkoutResponse.vehicleType}</span></div>
            <div className='checkout-receipt-data'>Validity      <span>{createOrderRequest.validity}d</span></div>
            <div className='checkout-receipt-data'>Amount        <span>₹{createOrderRequest.amount}</span></div>
            <button onClick={handlePayment}>Pay</button>
          </div>
        </div>
      }
    </>
  );
};

export default Checkout;
