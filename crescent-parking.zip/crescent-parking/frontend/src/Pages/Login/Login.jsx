import React, { useEffect, useState } from 'react';
import './Login.css';
import { Link, useNavigate } from 'react-router-dom';

const Login = ({setLoading}) => {
  const navigate = useNavigate();
  const [loginData, setLoginData] = useState({
    registerNumber: "",
    password: ""
  });

  const handleTextInput = (event) => {
    setLoginData(prev => ({
      ...prev,
      [event.target.name]: event.target.value
    }));
  };

  const handleLoginSubmit = () => {
    setLoading(true)
    fetch(`${import.meta.env.VITE_BACKEND_URL}/api/internalUser/login`, {
      method: 'POST',
      credentials: 'include',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({...loginData})
    })
      .then(res => res.json())
      .then(data => {
        if (data.message == 'Login successful') {
          navigate('/')
        }
        else {
          alert(data.message);
        }
      })
      .catch(err => console.log(err))
      .finally(() => {setLoading(false)})
  }

  useEffect(() => {
    const cookieString = document.cookie;
    const match = cookieString.match(/userInfo=([^;]+)/);
    if(match){
      navigate('/')
    }
  },[])

  return (
    <div className='login'>
      <img src="/assets/logo.png" alt="logo" className='login-logo' />
      <div className='login-heading'>Students / Staffs Login</div>
      <input
        type="text"
        placeholder='Register Number'
        name='registerNumber'
        onChange={handleTextInput}
        value={loginData.registerNumber}
      />
      <input
        type="password"
        placeholder='Password'
        name='password'
        onChange={handleTextInput}
        value={loginData.password}
      />
      <button className='login-submit' onClick={() => handleLoginSubmit()}>Login</button>
      <div className='login-links'>
        <Link to='/'>Home</Link>
        <Link to='/forgot-password'>Forget password?</Link>
      </div>
    </div>
  );
};

export default Login;
