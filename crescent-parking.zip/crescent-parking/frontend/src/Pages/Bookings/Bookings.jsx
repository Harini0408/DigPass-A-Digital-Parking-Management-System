import React, { useEffect, useState } from 'react';
import './Bookings.css';
import { useNavigate } from 'react-router-dom';
import Header from '../../Components/Header/Header';

const Bookings = () => {
    const navigate = useNavigate();
    const [reservations, setReservations] = useState([]);
    const [searchTerm, setSearchTerm] = useState('');

    useEffect(() => {
        const cookie = document.cookie
            .split('; ')
            .find(row => row.startsWith('userInfo='));
        if (cookie) {
            try {
                const _userInfo = JSON.parse(decodeURIComponent(cookie.split('=')[1]));
                if (_userInfo.role !== 'admin') {
                    navigate('/');
                    return;
                }
            } catch (err) {
                navigate('/');
                return;
            }
        } else {
            navigate('/');
            return;
        }

        fetch(`${import.meta.env.VITE_BACKEND_URL}/api/reservation/all`, {
            method: 'GET',
            credentials: 'include'
        })
            .then(res => res.json())
            .then(data => {
                setReservations(data);
            })
            .catch(err => {
                console.error(err);
                alert("Failed to fetch reservations");
            });
    }, []);

    const filtered = reservations.filter(r =>
        r.vehicleNumber?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        r.slotId?.toLowerCase().includes(searchTerm.toLowerCase())
    );

    return (
        <>
            <Header />
            <div className="bookings-container">
                <h2>All Bookings</h2>
                <input
                    type="text"
                    placeholder="Search by vehicle number or slot ID"
                    value={searchTerm}
                    onChange={e => setSearchTerm(e.target.value)}
                    className="search-input"
                />

                <div className="bookings-list">
                    {filtered.map((r, index) => (
                        <div key={index} className={`booking-card ${r.isExpired ? 'booking-card-expired' : ''}`} onClick={(e) => {e.target.closest('.booking-card').classList.contains('booking-card-active') ? e.target.closest('.booking-card').classList.remove('booking-card-active') : e.target.closest('.booking-card').classList.add('booking-card-active')}}>
                            <p><span>Slot:</span> {r.slotId} ({r.slotType})</p>
                            <p><span>Vehicle:</span> {r.vehicleNumber}</p>
                            <div className="booking-card-inner">
                                <p><span>Name:</span> {r.userName}</p>
                                <p><span>Email:</span> {r.userEmail}</p>
                                <p><span>User Type:</span> {r.userType}</p>
                                <p><span>Time:</span> {new Date(r.startTime).toLocaleString()} - {new Date(r.endTime).toLocaleString()}</p>
                                <p><span>Payment:</span> {r.paymentStatus}</p>
                                <p><span>Expire status:</span> {r.isExpired ? 'expired' : 'not expired'}</p>
                            </div>
                            <span className='booking-card-arrow'>&#11206;</span>
                        </div>
                    ))}
                </div>
            </div>
        </>
    );
};

export default Bookings;
