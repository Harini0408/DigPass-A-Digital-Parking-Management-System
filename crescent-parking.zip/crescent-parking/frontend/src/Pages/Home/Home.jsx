import React, { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import Header from '../../Components/Header/Header';
import './Home.css'

const Home = ({ setLoading }) => {

  const [vehicleType, setVehicleType] = useState("car");
  const [slotsData, setSlotsData] = useState(null);
  const [selectedSlot, setSelectedSlot] = useState(null);
  const [showMap, setShowMap] = useState(false)

  const handleVehicleTypeChange = (_vehicleType) => {
    setLoading(true);
    setVehicleType(_vehicleType);

    fetch(`${import.meta.env.VITE_BACKEND_URL}/api/slots/available/${_vehicleType}`)
      .then(res => res.json())
      .then(data => {
        setSelectedSlot(null)
        setLoading(false);
        setSlotsData(data)
      })
      .catch(err => {
        console.error(err);
        setSelectedSlot(null)
        setLoading(false);
      });
  }

  const handleSelectSlot = (slotId) => {
    setSelectedSlot(slotId);
  }

  useEffect(() => {
    handleVehicleTypeChange("car")
  }, [])

  return (
    <>
      <Header />
      <div className='home'>
        <div>
          <select className='home-vehicle-type-select' value={vehicleType} onChange={(e) => handleVehicleTypeChange(e.target.value)}>
            <option value="car">Car</option>
            <option value="bike">Bike</option>
          </select>
          <button className='home-button' onClick={() => {setShowMap(true)}}>View map</button>
        </div>
        <div className='home-slots'>
          {
            slotsData && slotsData.map((item) =>
              <div
                className={`home-slot ${item.isAvailable == false ? 'home-slot-disabled' : ''} ${item.slotId == selectedSlot ? 'home-slot-selected' : ''}`}
                key={item.slotId}
                onClick={() => item.isAvailable && handleSelectSlot(item.slotId)}
              >
                {item.slotId}
              </div>
            )
          }
        </div>
        {
          selectedSlot != null &&
          <div className='home-footer'>
            <div className='home-footer-info'>Selected slot : {selectedSlot}</div>
            <Link className='home-footer-proceed' to={`/checkout/${selectedSlot}`}>Proceed to pay</Link>
          </div>
        }
        {showMap ?
          <>
            {
              vehicleType == "car"
                ?
                <div className='parking-map-outer'>
                  <img src="/assets/car-parking.png" alt="car parking" className='parking-map' />
                  <div onClick={() => { setShowMap(false) }} className='parking-map-close'><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><g fill="none" fill-rule="evenodd"><path d="m12.593 23.258l-.011.002l-.071.035l-.02.004l-.014-.004l-.071-.035q-.016-.005-.024.005l-.004.01l-.017.428l.005.02l.01.013l.104.074l.015.004l.012-.004l.104-.074l.012-.016l.004-.017l-.017-.427q-.004-.016-.017-.018m.265-.113l-.013.002l-.185.093l-.01.01l-.003.011l.018.43l.005.012l.008.007l.201.093q.019.005.029-.008l.004-.014l-.034-.614q-.005-.018-.02-.022m-.715.002a.02.02 0 0 0-.027.006l-.006.014l-.034.614q.001.018.017.024l.015-.002l.201-.093l.01-.008l.004-.011l.017-.43l-.003-.012l-.01-.01z" /><path fill="#fff" d="m12 14.122l5.303 5.303a1.5 1.5 0 0 0 2.122-2.122L14.12 12l5.304-5.303a1.5 1.5 0 1 0-2.122-2.121L12 9.879L6.697 4.576a1.5 1.5 0 1 0-2.122 2.12L9.88 12l-5.304 5.304a1.5 1.5 0 1 0 2.122 2.12z" /></g></svg></div>
                </div>
                :
                <div className='parking-map-outer'>
                  <img src="/assets/bike-parking.png" alt="bike parking" className='parking-map' />
                  <div onClick={() => { setShowMap(false) }} className='parking-map-close'><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><g fill="none" fill-rule="evenodd"><path d="m12.593 23.258l-.011.002l-.071.035l-.02.004l-.014-.004l-.071-.035q-.016-.005-.024.005l-.004.01l-.017.428l.005.02l.01.013l.104.074l.015.004l.012-.004l.104-.074l.012-.016l.004-.017l-.017-.427q-.004-.016-.017-.018m.265-.113l-.013.002l-.185.093l-.01.01l-.003.011l.018.43l.005.012l.008.007l.201.093q.019.005.029-.008l.004-.014l-.034-.614q-.005-.018-.02-.022m-.715.002a.02.02 0 0 0-.027.006l-.006.014l-.034.614q.001.018.017.024l.015-.002l.201-.093l.01-.008l.004-.011l.017-.43l-.003-.012l-.01-.01z" /><path fill="#fff" d="m12 14.122l5.303 5.303a1.5 1.5 0 0 0 2.122-2.122L14.12 12l5.304-5.303a1.5 1.5 0 1 0-2.122-2.121L12 9.879L6.697 4.576a1.5 1.5 0 1 0-2.122 2.12L9.88 12l-5.304 5.304a1.5 1.5 0 1 0 2.122 2.12z" /></g></svg></div>
                </div>
            }
          </>
          :
          <></>
        }
      </div>
    </>
  )
}

export default Home