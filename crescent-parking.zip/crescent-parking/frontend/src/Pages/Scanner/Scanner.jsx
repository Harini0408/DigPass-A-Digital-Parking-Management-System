import React, { useEffect, useState } from 'react';
import './Scanner.css';
import Header from '../../Components/Header/Header';
import { Html5Qrcode } from 'html5-qrcode';
import { useNavigate } from 'react-router-dom';

const Scanner = () => {
    const navigate = useNavigate()
    const [reservationData, setReservationData] = useState(null);
    const [error, setError] = useState('');
    const [scanned, setScanned] = useState(false);

    useEffect(() => {
        const cookie = document.cookie
            .split('; ')
            .find(row => row.startsWith('userInfo='));
        if (cookie) {
            try {
                const _userInfo = JSON.parse(decodeURIComponent(cookie.split('=')[1]));
                if(_userInfo.role != 'admin'){
                    navigate('/')
                    return;
                }
            } catch (err) {
                console.log(err)
            }
        }
        else{
            navigate('/')
            return;
        }

        const html5QrCode = new Html5Qrcode("reader");

        html5QrCode.start(
            { facingMode: "environment" },
            {
                fps: 10,
            },
            async qrCodeMessage => {
                if (scanned) return; // Prevent duplicate scans
                setScanned(true);

                try {
                    const res = await fetch(`${import.meta.env.VITE_BACKEND_URL}/api/reservation/verify`, {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json'
                        },
                        credentials: 'include',
                        body: JSON.stringify({ reservationId: qrCodeMessage })
                    });

                    const data = await res.json();
                    if (res.ok) {
                        setReservationData(data.reservationDetails);
                        setError('');
                    } else {
                        setError(data.error || 'Failed to verify');
                        setReservationData(null);
                        if (data.error == "Unauthorized") {
                            navigate('/')
                            return;
                        }
                    }
                } catch (err) {
                    setError('Something went wrong while verifying.');
                    setReservationData(null);
                } finally {
                    await html5QrCode.stop();
                }
            },
            errorMessage => {
                // Optional: handle scan errors
            }
        ).catch(err => {
            alert(err);
        });

        return () => {
            html5QrCode.stop().then(() => {
                html5QrCode.clear();
            });
        };
    }, [scanned]);

    return (
        <>
            <Header />
            <div className='scanner'>
                <div id="reader" style={{ width: "500px" }}></div>

                {reservationData && (
                    <div className="result-card">
                        <img src="/assets/success.png" alt="success" />
                        <p><span>Name:</span> {reservationData.userName}</p>
                        <p><span>Email:</span> {reservationData.userEmail}</p>
                        <p><span>Slot:</span> {reservationData.slotId} ({reservationData.slotType})</p>
                        <p><span>Vehicle Number:</span> {reservationData.vehicleNumber}</p>
                        <p><span>Start:</span> {new Date(reservationData.startTime).toLocaleString()}</p>
                        <p><span>End:</span> {new Date(reservationData.endTime).toLocaleString()}</p>
                        <button onClick={() => { location.reload() }} className='scanner-button'>Reload</button>
                    </div>
                )}

                {error && (
                    <div className="error-card">
                        <img src="/assets/failed.png" alt="failed" />
                        {error}
                    </div>
                )}
            </div>
        </>
    );
}

export default Scanner;
