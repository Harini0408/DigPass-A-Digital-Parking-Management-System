import React from 'react'
import { Link, useParams } from 'react-router-dom'
import './Status.css'

const Status = () => {
    
    const {status,message} = useParams()
    
  return (
    <div className='status'>
      <img src={`/assets/${status}.png`} alt="status image" className='status-icon'/>
      <div className='status-msg'>{message}</div>
      <div className='login-links'>
        <Link to='/'>Home</Link>
      </div>
    </div>
  )
}

export default Status