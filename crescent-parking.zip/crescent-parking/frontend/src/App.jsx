import React, { useState } from 'react'
import {BrowserRouter, Route, Router, Routes} from 'react-router-dom'; 
import Home from './Pages/Home/Home';
import './App.css'
import Loading from './Components/Loading/Loading';
import Checkout from './Pages/Checkout/Checkout';
import Login from './Pages/Login/Login';
import ForgotPassword from './Pages/ForgotPassword/ForgotPassword';
import Status from './Pages/Status/Status';
import Scanner from './Pages/Scanner/Scanner';
import Bookings from './Pages/Bookings/Bookings';

const App = () => {

  const [loading,setLoading] = useState(false);

  return (
    <BrowserRouter>
      {loading===true && <Loading />}
      <Routes>
        <Route path='/' element={<Home setLoading={setLoading}/>}/>
        <Route path='/login' element={<Login setLoading={setLoading}/>}/>
        <Route path='/forgot-password' element={<ForgotPassword setLoading={setLoading}/>}/>
        <Route path='/checkout/:selectedSlot' element={<Checkout setLoading={setLoading}/>}/>
        <Route path='/status/:status/:message' element={<Status/>}/>
        <Route path='/scanner' element={<Scanner setLoading={setLoading}/>}/>
        <Route path='/bookings' element={<Bookings setLoading={setLoading}/>}/>
      </Routes>
    </BrowserRouter>
  )
}

export default App